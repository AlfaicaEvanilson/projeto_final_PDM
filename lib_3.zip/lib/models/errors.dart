enum EntryError {
  nameDuplicate,
  nameNull,
  dosage,
  type,
  interval,
  startTime,
  none,
}
