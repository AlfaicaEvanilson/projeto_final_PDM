enum MedicineType { bottle, pill, syringe, table, none }
